package com.example.cardx

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast

class ChangePassword : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_change_password)
    }

    fun Submit(view: View){
        Toast.makeText(applicationContext,"Password changed successfully, please login with the new password.", Toast.LENGTH_LONG).show()
        val intent = Intent(this, MainActivity::class.java).apply { }
        startActivity(intent)
    }
}
