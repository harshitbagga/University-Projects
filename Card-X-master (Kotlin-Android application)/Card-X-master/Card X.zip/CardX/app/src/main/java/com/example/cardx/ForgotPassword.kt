package com.example.cardx

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Toast

class ForgotPassword : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)
    }

    fun Submit(view: View){
        Toast.makeText(applicationContext,"You should receive the email shortly, use the temporary password to login and then change your password.", Toast.LENGTH_LONG).show()
        val intent = Intent(this, MainActivity::class.java).apply { }
        startActivity(intent)
    }
}
