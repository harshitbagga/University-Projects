package com.example.cardx

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ImageButton
import android.widget.Toast
import android.widget.PopupMenu


class MainPage : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_page)
    }



    fun CategorySelection(view:View){
        val B = findViewById<Button>(view.id)
        val BText = B.text
        Toast.makeText(applicationContext,"You changed the category to $BText", Toast.LENGTH_LONG).show()
    }

    fun OpenCard(view:View){
        val B = findViewById<ImageButton>(view.id)
        val BId = resources.getResourceEntryName(B.id)
        Toast.makeText(applicationContext,"You opened $BId", Toast.LENGTH_LONG).show()
        val intent = Intent(this, FullCard::class.java).apply { }
        startActivity(intent)
    }

    fun OpenProfile(view:View){
        val intent = Intent(this, Profile::class.java).apply { }
        startActivity(intent)
    }

    fun PopUpSettingsMenu(view:View){
        val PopUp = PopupMenu(this, view)
        val Inflater = PopUp.getMenuInflater()
        Inflater.inflate(R.menu.settings_menu, PopUp.getMenu())
        PopUp.setOnMenuItemClickListener { item ->
            when(item.itemId) {
                R.id.settings -> {
                val intent = Intent(this, Settings::class.java).apply { }
                    startActivity(intent)
                }

            }
            true
        }
        PopUp.show()

    }
}
